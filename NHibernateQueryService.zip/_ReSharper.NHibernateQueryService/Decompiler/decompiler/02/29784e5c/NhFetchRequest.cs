﻿// Type: NHibernate.Linq.NhFetchRequest`2
// Assembly: NHibernate, Version=3.3.1.4000, Culture=neutral, PublicKeyToken=aa95f207798dfdb4
// Assembly location: e:\Code\OData\NHibernateQueryService\packages\NHibernate.3.3.1.4000\lib\Net35\NHibernate.dll

using Remotion.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace NHibernate.Linq
{
  public class NhFetchRequest<TQueried, TFetch> : QueryableBase<TQueried>, INhFetchRequest<TQueried, TFetch>, IOrderedQueryable<TQueried>, IQueryable<TQueried>, IEnumerable<TQueried>, IOrderedQueryable, IQueryable, IEnumerable
  {
    public NhFetchRequest(IQueryProvider provider, Expression expression)
      : base(provider, expression)
    {
    }
  }
}

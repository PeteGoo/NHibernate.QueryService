﻿// Type: NHibernate.Linq.LinqExtensionMethods
// Assembly: NHibernate, Version=3.3.1.4000, Culture=neutral, PublicKeyToken=aa95f207798dfdb4
// Assembly location: e:\Code\OData\NHibernateQueryService\packages\NHibernate.3.3.1.4000\lib\Net35\NHibernate.dll

using NHibernate;
using NHibernate.Impl;
using Remotion.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace NHibernate.Linq
{
  public static class LinqExtensionMethods
  {
    public static IQueryable<T> Query<T>(this ISession session)
    {
      return (IQueryable<T>) new NhQueryable<T>(session.GetSessionImplementation());
    }

    public static IQueryable<T> Query<T>(this IStatelessSession session)
    {
      return (IQueryable<T>) new NhQueryable<T>(session.GetSessionImplementation());
    }

    public static IQueryable<T> Cacheable<T>(this IQueryable<T> query)
    {
      // ISSUE: method reference
      MethodCallExpression methodCallExpression = Expression.Call(ReflectionHelper.GetMethodDefinition(Expression.Lambda<Action>((Expression) Expression.Call((Expression) null, (MethodInfo) MethodBase.GetMethodFromHandle(__methodref (LinqExtensionMethods.Cacheable)), new Expression[1]
      {
        (Expression) Expression.Constant((object) (IQueryable<object>) null, typeof (IQueryable<object>))
      }), new ParameterExpression[0])).MakeGenericMethod(new Type[1]
      {
        typeof (T)
      }), new Expression[1]
      {
        query.Expression
      });
      return (IQueryable<T>) new NhQueryable<T>(query.Provider, (Expression) methodCallExpression);
    }

    public static IQueryable<T> CacheMode<T>(this IQueryable<T> query, CacheMode cacheMode)
    {
      // ISSUE: method reference
      MethodCallExpression methodCallExpression = Expression.Call(ReflectionHelper.GetMethodDefinition(Expression.Lambda<Action>((Expression) Expression.Call((Expression) null, (MethodInfo) MethodBase.GetMethodFromHandle(__methodref (LinqExtensionMethods.CacheMode)), new Expression[2]
      {
        (Expression) Expression.Constant((object) (IQueryable<object>) null, typeof (IQueryable<object>)),
        (Expression) Expression.Constant((object) CacheMode.Normal, typeof (CacheMode))
      }), new ParameterExpression[0])).MakeGenericMethod(new Type[1]
      {
        typeof (T)
      }), new Expression[2]
      {
        query.Expression,
        (Expression) Expression.Constant((object) cacheMode)
      });
      return (IQueryable<T>) new NhQueryable<T>(query.Provider, (Expression) methodCallExpression);
    }

    public static IQueryable<T> CacheRegion<T>(this IQueryable<T> query, string region)
    {
      // ISSUE: method reference
      MethodCallExpression methodCallExpression = Expression.Call(ReflectionHelper.GetMethodDefinition(Expression.Lambda<Action>((Expression) Expression.Call((Expression) null, (MethodInfo) MethodBase.GetMethodFromHandle(__methodref (LinqExtensionMethods.CacheRegion)), new Expression[2]
      {
        (Expression) Expression.Constant((object) (IQueryable<object>) null, typeof (IQueryable<object>)),
        (Expression) Expression.Constant((object) null, typeof (string))
      }), new ParameterExpression[0])).MakeGenericMethod(new Type[1]
      {
        typeof (T)
      }), new Expression[2]
      {
        query.Expression,
        (Expression) Expression.Constant((object) region)
      });
      return (IQueryable<T>) new NhQueryable<T>(query.Provider, (Expression) methodCallExpression);
    }

    public static IEnumerable<T> ToFuture<T>(this IQueryable<T> query)
    {
      QueryableBase<T> queryableBase = query as QueryableBase<T>;
      if (queryableBase == null)
        throw new NotSupportedException("Query needs to be of type QueryableBase<T>");
      else
        return (IEnumerable<T>) ((INhQueryProvider) queryableBase.Provider).ExecuteFuture(queryableBase.Expression);
    }

    public static IFutureValue<T> ToFutureValue<T>(this IQueryable<T> query)
    {
      QueryableBase<T> queryableBase = query as QueryableBase<T>;
      if (queryableBase == null)
        throw new NotSupportedException("Query needs to be of type QueryableBase<T>");
      object future = ((INhQueryProvider) queryableBase.Provider).ExecuteFuture(queryableBase.Expression);
      if (future is DelayedEnumerator<T>)
        return (IFutureValue<T>) new FutureValue<T>((FutureValue<T>.GetResult) (() => (IEnumerable<T>) future));
      else
        return (IFutureValue<T>) future;
    }
  }
}

﻿using System.Linq;
using System.Web;
using NHibernate;

namespace NHibernateQueryService.Model {
    public static class NHibernateExtensions {
        public static IQueryable<TEntity> Include<TEntity>(this IQueryable<TEntity> query, params string[] properties) {
            if(query is NHibernate.Linq.NhQueryable<TEntity>) {
                NHibernate.Linq.NhQueryable<TEntity> nquery = (NHibernate.Linq.NhQueryable<TEntity>) query;
            }
            //    var queryOver = .QueryOver<TEntity>();

            //    var criteria = queryOver.UnderlyingCriteria;

            //    foreach (var property in properties) {
            //        criteria.SetFetchMode(property, FetchMode.Eager);
            //    }

            //    return queryOver;
            return query;
        }

        public static IQueryable<T> ProcessExpands<T>(this IQueryable<T> source) where T : class {
            string expandsQueryString = HttpContext.Current.Request.QueryString["$expand"];
            if (string.IsNullOrWhiteSpace(expandsQueryString)) {
                return source;
            }

            IQueryable<T> query = source;

            expandsQueryString.Split(',').Select(s => s.Trim()).ToList().ForEach(
                expand => {
                    query = query.Include(expand.Replace("/", "."));
                });

            return query;
        }
    }
}